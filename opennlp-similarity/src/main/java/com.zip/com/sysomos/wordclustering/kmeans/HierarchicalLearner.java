package com.sysomos.wordclustering.kmeans;

import java.util.ArrayList;
import java.util.List;

import com.sysomos.wordclustering.GlobalConstants;
import com.sysomos.wordclustering.node.ClusterClusterNode;
import com.sysomos.wordclustering.node.ClusterNode;
import com.sysomos.wordclustering.node.WordClusterNode;
import com.sysomos.wordclustering.node.WordNode;

public class HierarchicalLearner {
	private KMeansLearner rootLearner;
	private boolean useSimilarity;
	private List<WordNode> rootWordNodeList;
	
	public HierarchicalLearner() {
		rootWordNodeList = new ArrayList<WordNode>(GlobalConstants.WORD_COUNT);
		useSimilarity = false;
	}
	
	public void addWordNode(WordNode wordNode) {
		rootWordNodeList.add(wordNode);
	}
	
	public ClusterNode<?> learn() {
		rootLearner = createLearner(rootWordNodeList, null);
		recursiveLearn(rootLearner);
		
		return rootLearner.getResultCluster();
	}
	
	private void recursiveLearn(KMeansLearner learner) {
		if (learner == null)
			return;
		
		List<WordClusterNode> clusterNodeList = learner.learn();
		if (clusterNodeList != null && clusterNodeList.size() > 1) {
			ClusterClusterNode resultCluster = new ClusterClusterNode();
			learner.setResultCluster(resultCluster);
			for (WordClusterNode clusterNode : clusterNodeList) {
				// continue to split in each cluster
				KMeansLearner childLearner = createLearner(clusterNode.getChildrenList(), learner);
				recursiveLearn(childLearner);
			}
		} else if (clusterNodeList.size() == 1) {
			// this is a leaf cluster
			WordClusterNode resultCluster = clusterNodeList.get(0);
			learner.setResultCluster(resultCluster);
		}
		
		// release the children nodes
		learner.getWordNodeList().clear();
	}

	private KMeansLearner createLearner(List<WordNode> wordNodeList, KMeansLearner parentLearner) {
		if (useSimilarity)
			return new KMeansLearnerBySimilarity(wordNodeList, parentLearner);
		else
			return new KMeansLearnerByDistance(wordNodeList, parentLearner);
	}
}
