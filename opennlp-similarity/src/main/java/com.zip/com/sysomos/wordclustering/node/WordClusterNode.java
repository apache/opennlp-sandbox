package com.sysomos.wordclustering.node;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import com.sysomos.wordclustering.util.IoUtil;

public class WordClusterNode extends ClusterNode<WordNode> {
	@Override
	public void outputResult(String dirPath) throws IOException {
		File dir = new File(dirPath);
		if (!dir.exists()) {
			dir.mkdirs();
		}
		
		String centroidWord = getCentroidWord();
		String filePath = IoUtil.concatPaths(dirPath, centroidWord + ".txt");
		File dataFile = new File(filePath);
		if (dataFile.exists())
			dataFile.delete();
		
		try (PrintWriter writer = new PrintWriter(new FileWriter(filePath, true))) {
			for (WordNode wordNode : childrenList) {
				writer.println(wordNode.getWord());
			}
		}
	}
}
