package com.sysomos.wordclustering.tool;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.regex.Pattern;

public class WordCleaner {
	private static final String inputPath = "/Users/hchen/Documents/Sysomos_Tech/data/word2vec/word2vec_dump_clean.txt";
	private static final String outputPath = "/Users/hchen/Documents/Sysomos_Tech/data/word2vec/word2vec_moderate_clean.txt";
	
	//private static final Pattern NON_WORD_PATTERN = Pattern.compile("[^a-zA-Z0-9-_]+");
	//private static final Pattern NON_WORD_PATTERN = Pattern.compile("[^a-z]+");
	private static final Pattern WORD_PATTERN = Pattern.compile("^[a-zA-Z]+(_[a-zA-Z]+){0,1}$");
	
	private void clean() throws Exception {
		
		try (BufferedReader reader = new BufferedReader(new FileReader(inputPath)); 
				PrintWriter writer = new PrintWriter(new FileWriter(outputPath))) 
		{
			String line = null;
			while ((line = reader.readLine()) != null) {
				if (validWord(line)) {
					writer.println(line);
				}
			}
		}
	}
	
	private boolean validWord(String line) {
		if (line.trim().length() == 0)
			return false;
		
		int colonPos = line.indexOf(":[");
		String word = line.substring(0, colonPos).trim();
		if (WORD_PATTERN.matcher(word).find()) {
			return true;
		} else {
			return false;
		}
	}

	public static void main(String[] args) throws Exception {
		WordCleaner instance = new WordCleaner();
		instance.clean();
	}
}
