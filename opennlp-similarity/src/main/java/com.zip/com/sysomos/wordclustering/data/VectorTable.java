package com.sysomos.wordclustering.data;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.sysomos.wordclustering.GlobalConstants;

public class VectorTable {
	private static volatile VectorTable instance;
	Map<String, float[]> wordMap;
	
	public static VectorTable getInstance() {
		if (instance == null)
			instance = new VectorTable();
		
		return instance;
	}
	
	private VectorTable() {
		wordMap = new HashMap<String, float[]>(GlobalConstants.WORD_COUNT, 1);
	}
	
	public float[] getVector(String word) {
		if (word == null)
			return null;
		
		return wordMap.get(word);
	}
	
	public void addWordVector(String word, float[] vector) {
		if (word == null) {
			System.err.println("Word cannot be null.");
			return;
		}
				
		wordMap.put(word, vector);
	}
	
	public Iterator<String> getWordIterator() {
		return wordMap.keySet().iterator();
	}
}
