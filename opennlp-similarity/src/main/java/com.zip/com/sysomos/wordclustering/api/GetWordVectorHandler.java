package com.sysomos.wordclustering.api;

import java.util.Map;

import com.sysomos.wordclustering.data.VectorTable;
import com.sysomos.wordclustering.util.StringUtil;

public class GetWordVectorHandler extends CommandHandler {
	public static final String ARGUMENT_WORD = "word";
	public static final String[] ARGUMENT_LIST = {ARGUMENT_WORD};

	public GetWordVectorHandler() {
		super("getWordVector");
	}

	@Override
	public String[] getArguments() {
		return ARGUMENT_LIST;
	}

	@Override
	public void handle(Map<String, String> argumentMap) throws HandlerException {
		String word = argumentMap.get(ARGUMENT_WORD);
		if (StringUtil.empty(word)) {
			System.out.println("Empty word");
			return;
		}
		
		word = word.trim();		
		float[] vector = VectorTable.getInstance().getVector(word);
		 
		if (vector == null) {
			System.out.println("Vector not available for word: " + word);
		} else {
			System.out.println(word + ": " + formatVector(vector));
		}
	}
}
