package com.sysomos.wordclustering.node;

import java.io.IOException;

import com.sysomos.wordclustering.data.WordTable;

public class WordNode extends AbstractNode {
	private static final float[] VARIATION = getZeroVariation();
	
	private String word;
	
	public WordNode(String word) {
		super();
		
		this.word = word;
	}

	public float[] getVector() {
		return WordTable.getInstance().getVector(word);
	}

	public String getWord() {
		return word;
	}

	public void setWord(String word) {
		this.word = word;
	}
	
	@Override
	public float[] getMean() {
		return getVector();
	}

	@Override
	public float[] getVariation() {
		return VARIATION;
	}
	
	private static float[] getZeroVariation() {
		float[] variation = new float[VECTOR_LENGTH];
		for (int i = 0; i < variation.length; i++) {
			variation[i] = 0;
		}
		
		return variation;
	}

	public String getCentroidWord() {
		return word;
	}

	@Override
	public void outputResult(String dirPath) throws IOException {
		// a word node has nothing to output
	}
}
