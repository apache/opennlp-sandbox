package com.sysomos.wordclustering.node;

import java.util.ArrayList;
import java.util.List;

import com.sysomos.wordclustering.data.VectorValue;
import com.sysomos.wordclustering.data.WordSignature;
import com.sysomos.wordclustering.util.VectorOperations;

public abstract class ClusterNode<T extends AbstractNode> extends AbstractNode {
	protected VectorValue mean;
	protected VectorValue variation;
	protected String centroidWord;
	protected List<T> childrenList;
	
	public ClusterNode() {
		super();
		
		childrenList = new ArrayList<T>();
	}
	
	public void addChildNode(T childNode) {
		childrenList.add(childNode);
	}
	
	public List<T> getChildrenList() {
		return childrenList;
	}
	
	public void setChildrenList(List<T> childrenList) {
		this.childrenList = childrenList;
	}

	public WordSignature getSignature() {
		// if the cluster contains only one node, use the result from that node, to save memory
		if (childrenList.size() == 1) {
			return childrenList.get(0).getSignature();
		}
				
		return super.getSignature();
	}
	
	public void setMean(float[] meanVector) {
		if (meanVector == null) {
			if (mean != null) {
				mean.clear();
				mean = null;
			}
			
			return;
		}
		
		if (mean == null)
			mean = new VectorValue(meanVector);
		else
			mean.setVector(meanVector);		
	}
	
	public float[] getMean() {
		if (mean != null)
			return mean.getVector();
		
		// if the cluster contains only one node, use the result from that node, to save memory
		if (childrenList.size() == 1) {
			return childrenList.get(0).getMean();
		}

		// if we are here, the variation has not been generated
		refreshMeanAndVariation();
		
		return mean.getVector();
	}
	
	public float[] getVariation() {
		if (variation != null)
			return variation.getVector();
		
		// if the cluster contains only one node, use the result from that node, to save memory
		if (childrenList.size() == 1) {
			return childrenList.get(0).getVariation();
		}

		// if we are here, the variation has not been generated
		refreshMeanAndVariation();
		
		return variation.getVector();
	}
	
	public void refreshMeanAndVariation() {
		VectorValue[] meanAndVariation = generateMeanAndVariation();
		mean = meanAndVariation[0];
		variation = meanAndVariation[1];		
	}
	
	public String getCentroidWord() {
		// if the cluster contains only one node, use the result from that node, to save memory
		if (childrenList.size() == 1) {
			return childrenList.get(0).getCentroidWord();
		}

		if (centroidWord == null)
			centroidWord = findCentroidWord();
		
		return centroidWord;
	}

	
	public WordSignature getGenericSignature() {
		int dimensionCount = childrenList.get(0).getMean().length;
		WordSignature signature = new WordSignature(dimensionCount);
		
		// clear all the bits to make it generic
		signature.clear();
		
		return signature;
	}
	
	public void destroy() {
		signature = null;
		mean.setVector(null);
		mean = null;
		variation.setVector(null);
		variation = null;
		centroidWord = null;
		childrenList.clear();
		childrenList = null;
	}

	private VectorValue[] generateMeanAndVariation() {
		// calculate mean from the means of children nodes
		if (childrenList == null || childrenList.size() == 0) {
			System.err.println("Empty childen list");
			return null;
		}
		
		int dimensionCount = childrenList.get(0).getMean().length;
		float[] mean = new float[dimensionCount];
		float[] variation = new float[dimensionCount];
		for (int dimension = 0; dimension < dimensionCount; dimension++) {
			float sum = 0;
			float squareSum = 0;
			float childrenCount = childrenList.size();
			for (T child : childrenList) {
				float childMean = child.getMean()[dimension];
				sum += childMean;
				squareSum += childMean*childMean;
			}
			
			mean[dimension] = sum / childrenCount;
			variation[dimension] = (float) Math.sqrt(squareSum / childrenCount - mean[dimension]*mean[dimension]);
		}
				
		VectorValue[] result = new VectorValue[2];
		result[0] = new VectorValue(mean);
		result[1] = new VectorValue(variation);
		
		return result;
	}
	
	private String findCentroidWord() {
		// find the node that is minimum distance form the mean value
		float[] clusterMean = getMean();
		
		float minDistance = -1;
		int centroidIndex = -1;
		for (int i = 0; i < childrenList.size(); i++) {
			T child = childrenList.get(i);
			float[] childMean = child.getMean();
			float distance = VectorOperations.getDistance(childMean, clusterMean, 1);
			if (centroidIndex < 0 || distance < minDistance) {
				centroidIndex = i;
				minDistance = distance;
			}			
		}
		
		String centroidWord = childrenList.get(centroidIndex).getCentroidWord();
		
		return centroidWord;
	}
}
