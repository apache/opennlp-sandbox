package com.sysomos.wordclustering;

public interface GlobalConstants {
	String INPUT_DIR = "/Users/bgalitsky/Documents/relevance-based-on-parse-trees/src/test/resources/w2v/word2vec_lower_case.txt";
	String OUTPUT_DIR = "/Users/hchen/Documents/Sysomos_Tech/data/word2vec/clustering_result";
	int WORD_COUNT = 160000;
}
