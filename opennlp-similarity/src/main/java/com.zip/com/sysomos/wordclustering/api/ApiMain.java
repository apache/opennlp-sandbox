package com.sysomos.wordclustering.api;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

import com.sysomos.wordclustering.GlobalConstants;
import com.sysomos.wordclustering.data.NamedVector;
import com.sysomos.wordclustering.data.VectorTable;
import com.sysomos.wordclustering.node.AbstractNode;

public class ApiMain {
	public static final CommandHandler[] HANDLERS = {
			new GetWordVectorHandler(),
			new GetNearestWordsHandler(),
			new GetWordDiffHandler()
		};

	Map<String, CommandHandler> handlerMap;

	public ApiMain() {
		handlerMap = new HashMap<String, CommandHandler>();
    	for (CommandHandler handler : HANDLERS) {
    		handlerMap.put(handler.getMethodName().toLowerCase(), handler);
    	}
	}

	private void loadVectorTable() throws Exception {
		VectorTable vectorTable = VectorTable.getInstance();
		
		try (BufferedReader reader = new BufferedReader(new FileReader(GlobalConstants.INPUT_DIR))) {
			String line = null;
			NamedVector resultHolder = new NamedVector("place holder", new float[AbstractNode.VECTOR_LENGTH]);
			while ((line = reader.readLine()) != null) {
				boolean success = parseLine(line, resultHolder);
				if (success) {
					String word = resultHolder.getName();
					float[] vector = resultHolder.getVector();
					vectorTable.addWordVector(word, vector);
				}
			}
		}
	}
	
	private boolean parseLine(String line, NamedVector resultHolder) {
		if (line.trim().length() == 0)
			return false;
		
		int colonPos = line.indexOf(":[");
		String word = line.substring(0, colonPos).trim();
		
		int closingBracket = line.indexOf("]", colonPos + 2);
		String vectorSting = line.substring(colonPos + 2, closingBracket);
		String[] valueStrings = vectorSting.split("\\,");
		
		float[] vector = new float[valueStrings.length];
		for (int i = 0; i < valueStrings.length; i++) {
			vector[i] = Float.parseFloat(valueStrings[i].trim());
		}
		
		resultHolder.setName(word);
		resultHolder.setVector(vector);
		
		return true;
	}
			
	public static void main(String[] args) throws Exception {
		BufferedReader commandLineIn = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("====================================================");
		System.out.println("Loading vector model, please wait ... ...");
		System.out.println("====================================================");
		
		ApiMain instance = new ApiMain();
		instance.loadVectorTable();
		
		while(true) {
			CommandHandler methodHandler = instance.getMethodHandler(commandLineIn);
			if (methodHandler == null) {
				System.exit(0);
			} else {
				String[] arguments = methodHandler.getArguments();
				Map<String, String> argumentMap = instance.getArguments(arguments, commandLineIn);
				
				System.out.println("Handling method: " + methodHandler.getMethodName() + " ...");
				try {
					methodHandler.handle(argumentMap);
				} catch (Exception e) {
					System.out.println("Failed to handle method, error: " + e);
					e.printStackTrace();
				}
			}
		}
	}
	
	String lastMethodName = null;
	private CommandHandler getMethodHandler(BufferedReader commandLineIn) throws Exception {
		CommandHandler handler = null;
		while(true) {
			System.out.printf("Enter method: ");
			
			String methodName = commandLineIn.readLine().trim();
			if (methodName.equals("quit")) {
				break;
			} else if (methodName.equals(".")) {
				if (lastMethodName != null) {
					System.out.printf("Enter Word2Vec method: " + lastMethodName + "\n");
					methodName = lastMethodName;
				} else {
					System.out.printf("There is no last method name to use.\n");
					continue;
				}				
			}
			
			handler = handlerMap.get(methodName.toLowerCase());
			if (handler == null) {
				System.out.println("Invalid method: " + methodName + "\n");
			} else {
				// found a valid handler, finish
				lastMethodName = methodName;
				break;
			}
		}
		
		return handler;
	}
	
	private Map<String, String> getArguments(String[] arguments, BufferedReader commandLineIn) 
			throws Exception
	{
		if (arguments == null || arguments.length == 0)
			return null;
		
		Map<String, String> argumentMap = new HashMap<String, String>();
		for (int i = 0; i < arguments.length; i++) {
			System.out.printf("Enter value for argument, " + arguments[i] + ": ");
			String value = commandLineIn.readLine().trim();
			if (value.equals("back")) {
				i--;
				continue;
			} else {
				argumentMap.put(arguments[i], value);
			}
		}
		
		return argumentMap;
	}
}
