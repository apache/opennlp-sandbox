package com.sysomos.wordclustering.api;

import java.util.Map;

import com.sysomos.wordclustering.data.VectorTable;
import com.sysomos.wordclustering.node.AbstractNode;

public class GetWordDiffHandler extends CommandHandler {
	public static final String ARGUMENT_REFERENCE_WORDS = "reference word";
	public static final String ARGUMENT_WORD_LIST = "word list";
	public static final String[] ARGUMENT_LIST = {ARGUMENT_REFERENCE_WORDS, ARGUMENT_WORD_LIST};

	public GetWordDiffHandler() {
		super("getWordDiff");
	}

	@Override
	public String[] getArguments() {
		return ARGUMENT_LIST;
	}

	@Override
	public void handle(Map<String, String> argumentMap) throws HandlerException {
		String referenceWord = argumentMap.get(ARGUMENT_REFERENCE_WORDS);
		String wordsStr = argumentMap.get(ARGUMENT_WORD_LIST);
		String[] words = wordsStr.split("\\,");
		
		VectorTable vectorTable = VectorTable.getInstance();
		
		float[] referenceVector = vectorTable.getVector(referenceWord);
		System.out.println(referenceWord + ": " + formatVector(referenceVector));

		for (String word : words) {
			float[] wordVector = vectorTable.getVector(word);
			//float[] diffVector = VectorOperations.subtraction(wordVector, referenceVector);
			float[] diffVector = getDiff(wordVector, referenceVector);
			System.out.println(word + " - : \t\t" + formatVector(diffVector));
		}		
	}
	
	private float[] getDiff(float[] vector1, float[] vector2) {
		float[] diff = new float[vector1.length];
		for (int i = 0; i < vector1.length; i++) {
			if (vector1[i] > AbstractNode.THRESHOLD) {
				if (vector2[i] > AbstractNode.THRESHOLD) {
					diff[i] = 0;
				} else if (vector2[i] > -AbstractNode.THRESHOLD) {
					diff[i] = 1;
				} else {
					diff[i] = 2;
				}

			} else if (vector1[i] > -AbstractNode.THRESHOLD) {
				if (vector2[i] > AbstractNode.THRESHOLD) {
					diff[i] = 3;
				} else if (vector2[i] > -AbstractNode.THRESHOLD) {
					diff[i] = 4;
				} else {
					diff[i] = 5;
				}
			} else {
				if (vector2[i] > AbstractNode.THRESHOLD) {
					diff[i] = 6;
				} else if (vector2[i] > -AbstractNode.THRESHOLD) {
					diff[i] = 7;
				} else {
					diff[i] = 8;
				}
			}
		}
		
		return diff;
	}
}
