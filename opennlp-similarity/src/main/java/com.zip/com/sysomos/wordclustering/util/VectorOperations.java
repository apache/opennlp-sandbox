package com.sysomos.wordclustering.util;

public class VectorOperations {
	
	/**
	 * @param norm 1 means sum of absolute values, 2 means normal distance
	 */
	public static float getDistance(float[] vector1, float[] vector2, int norm) {
		if (vector1 == null || vector2 == null || vector1.length != vector2.length)
			throw new NullPointerException("Invalid vectors for distance.");
		
		float sum = 0;
		for (int i = 0; i < vector1.length; i++) {
			float delta = vector1[i] - vector2[i];
			if (norm == 1) {
				sum += Math.abs(delta);
			} else {
				sum += delta * delta;
			}
		}
		
		if (norm == 1)
			return sum;
		else
			return (float) Math.sqrt(sum);
	}

	public static float dotProduct(float[] vector1, float[] vector2) {
		if (vector1 == null || vector2 == null || vector1.length != vector2.length)
			return 0;
		
		float product = 0;
		for (int i = 0; i < vector1.length; i++) {
			product += vector1[i] * vector2[i];
		}
		
		return product;
	}
	
	public static float[] subtraction(float[] vector1, float[] vector2) {
		float[] diff = new float[vector1.length];
		for (int i = 0; i < vector1.length; i++) {
			diff[i] = vector1[i] - vector2[i];
		}
		
		return diff;
	}
}
