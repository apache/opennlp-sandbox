package com.sysomos.wordclustering.data;

import java.util.BitSet;

public class WordSignature extends BitSet {
	private static final long serialVersionUID = 1L;
	
	private int dimensionCount;
	
	/*
	 * We use 2 bits to represent the value of a dimension
	 * One bit in the first half (0 - N) to represent high positives.
	 * One bit in the second half (N - 2N) to represent high negatives.
	 * where N is the number of dimensions.
	 */
	private static final int BITS_PER_DIMENSION = 2;
	
	public WordSignature(int dimensionCount) {
		super(dimensionCount * BITS_PER_DIMENSION);
		this.dimensionCount = dimensionCount;
	}
		
	public void setDimension(int dimensionPos, SignatureValue value) {
		// we use two bits to represent a dimension
		int highBitPos = dimensionPos;
		int lowBitPos = dimensionPos + dimensionCount;
		
		// set the two bits
		set(highBitPos, value.getHighBit());
		set(lowBitPos, value.getLowBit());
	}
	
	public int getDimensionCount() {
		return dimensionCount;
	}
	
	public int getBitCount() {
		return dimensionCount * BITS_PER_DIMENSION;
	}
	
	public static void copy(WordSignature copyTo, WordSignature copyFrom) {
		if (copyTo == null || copyFrom == null) {
			System.err.println("Word signature to copy must not be null.");
			return;
		}
		
		// set the the signature copyTo to all 1s, and then AND with copyFrom.
		// the result is in copyTo
		// please note that the size() and length() functions of BitSet do not return the number of bits
		copyTo.set(0, copyTo.getBitCount(), true);
		copyTo.and(copyFrom);
	}
	
	public static void main(String[] args) {
		WordSignature ws1 = new WordSignature(10);
		ws1.set(0, 5, true);
		System.out.println("dimensions = " + ws1.getDimensionCount() + ", cardinality = " + ws1.cardinality());
		
		WordSignature ws2 = new WordSignature(10);
		WordSignature.copy(ws2, ws1);
		System.out.println("ws2 == ws1 ? " + ws2.equals(ws1));
		System.out.println("dimensions = " + ws2.getDimensionCount() + ", cardinality = " + ws2.cardinality());
		
		WordSignature ws3 = (WordSignature) ws1.clone();
		System.out.println("dimensions = " + ws3.getDimensionCount() + ", cardinality = " + ws3.cardinality());
		System.out.println("ws3 == ws1 ? " + ws3.equals(ws1));
	}
}
