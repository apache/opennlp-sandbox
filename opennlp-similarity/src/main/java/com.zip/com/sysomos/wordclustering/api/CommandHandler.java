package com.sysomos.wordclustering.api;

import java.text.DecimalFormat;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

public abstract class CommandHandler {
	private static final DecimalFormat DECIMAL_FORMAT = new DecimalFormat("#.###");

	protected String methodName;
	
	public CommandHandler(String methodName) {
		this.methodName = methodName;
	}

	public abstract String[] getArguments();
	public abstract void handle(Map<String, String> argumentMap) throws HandlerException;

	public String getMethodName() {
		return methodName;
	}
			
	public static String formatVector(float[] vector) {
		if (vector == null)
			return null;
		
		StringBuilder builder = new StringBuilder("[" +  formatValue(vector[0]));
		
		for (int i = 1; i < vector.length; i++) {
			builder.append(", " + formatValue(vector[i]));
		}
		builder.append("]");
		
		return builder.toString();
	}

	public static String formatValue (float value) {
		return DECIMAL_FORMAT.format(value);
	}
		
	protected void sortWordList(List<SimilarWord> wordList) {
		Comparator<SimilarWord> comparator = new Comparator<SimilarWord>() {

			@Override
			public int compare(SimilarWord word1, SimilarWord word2) {
				return (int)Math.signum(word2.similarity - word1.similarity);
			}			
		};
		
		Collections.sort(wordList, comparator);
	}
	
	protected void outputWordList(List<SimilarWord> wordList) {
		for (SimilarWord similarWord : wordList) {
			System.out.println(formatValue(similarWord.similarity) + "\t" + similarWord.word);
		}
	}
}
