package com.sysomos.wordclustering.util;

public class StringUtil {
	
	public static boolean empty(String value) {
		return ((value == null) || (value.trim().length() == 0));
	}
}
