package com.sysomos.wordclustering.api;

import java.util.Iterator;
import java.util.Map;

import com.sysomos.wordclustering.data.VectorTable;
import com.sysomos.wordclustering.util.VectorOperations;

public class GetNearestWordsHandler extends CommandHandler {
	public static final String ARGUMENT_SEED_WORD = "seed word";
	public static final String ARGUMENT_NUMBER_WORDS = "number of words";
	public static final String[] ARGUMENT_LIST = {ARGUMENT_SEED_WORD, ARGUMENT_NUMBER_WORDS};

	public GetNearestWordsHandler() {
		super("getNearestWords");
	}

	@Override
	public String[] getArguments() {
		return ARGUMENT_LIST;
	}

	@Override
	public void handle(Map<String, String> argumentMap) throws HandlerException {
		String seedWord = argumentMap.get(ARGUMENT_SEED_WORD);
		String countStr = argumentMap.get(ARGUMENT_NUMBER_WORDS);
		int count = Integer.parseInt(countStr);
		
		SimilarWordQueue nearestWordQueue = new SimilarWordQueue(count);
		SimilarWordQueue nearestWordSumQueue = new SimilarWordQueue(count);
		SimilarWordQueue similarWordQueue = new SimilarWordQueue(count);
		
		getNearestWords(seedWord, nearestWordQueue, nearestWordSumQueue, similarWordQueue);
		
		outputNearestWords(seedWord, nearestWordQueue, nearestWordSumQueue, similarWordQueue);
	}

	private void getNearestWords(String seedWord, SimilarWordQueue nearestWordQueue,
			SimilarWordQueue nearestWordSumQueue, SimilarWordQueue similarWordQueue)
	{
		VectorTable vectorTable = VectorTable.getInstance();
		float[] seedVector = vectorTable.getVector(seedWord);
		
		Iterator<String> wordIterator = vectorTable.getWordIterator();
		while (wordIterator.hasNext()) {
			String tempWord = wordIterator.next();
			float[] tempVector = vectorTable.getVector(tempWord);
			float distance = VectorOperations.getDistance(seedVector, tempVector, 2);
			float distanceSum = VectorOperations.getDistance(seedVector, tempVector, 1);
			float similarity = VectorOperations.dotProduct(seedVector, tempVector);
			nearestWordQueue.add(new SimilarWord(tempWord, (1f - distance)));
			nearestWordSumQueue.add(new SimilarWord(tempWord, (1f - distanceSum)));
			similarWordQueue.add(new SimilarWord(tempWord, similarity));
		}
	}
	
	private void outputNearestWords(String seedWord, SimilarWordQueue nearestWordQueue,
			SimilarWordQueue nearestWordSumQueue, SimilarWordQueue similarWordQueue)
	{
		outputQueue("Nearest words for " + seedWord, nearestWordQueue);
		
		System.out.println("===================================");
		
		outputQueue("Nearest words by sum for " + seedWord, nearestWordSumQueue);
		
		System.out.println("===================================");
		
		outputQueue("Similarest words for " + seedWord, similarWordQueue);
		
		System.out.println("===================================");
	}
	
	private void outputQueue(String label, SimilarWordQueue queue) {
		System.out.println(label);
		for (SimilarWord similarWord : queue.getWordList()) {
			System.out.println(similarWord.word + ":\t" + formatValue(similarWord.similarity));
		}
	}
}
