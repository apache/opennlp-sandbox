package com.sysomos.wordclustering.node;

import java.io.IOException;

import com.sysomos.wordclustering.data.SignatureValue;
import com.sysomos.wordclustering.data.WordSignature;
import com.sysomos.wordclustering.util.VectorOperations;

public abstract class AbstractNode {
	public static final float THRESHOLD = 0.05f;
	public static final int VECTOR_LENGTH = 300;
	
	protected WordSignature signature;
	
	public abstract void outputResult(String dirPath) throws IOException;
	
	public abstract float[] getMean();
	
	public abstract float[] getVariation();
	
	public abstract String getCentroidWord();
	
	public void setSignature(WordSignature signature) {
		this.signature = signature;
	}

	public WordSignature getSignature() {
		if (signature == null) {
			signature = generateSignature();
		}
		
		return signature;
	}

	protected WordSignature generateSignature() {
		float[] mean = getMean();
		
		WordSignature signature = new WordSignature(mean.length);
		for (int dimension = 0; dimension < mean.length; dimension++) {
			SignatureValue signatureValue = toSignatureValue(mean[dimension]);
			signature.setDimension(dimension, signatureValue);
		}
		
		return signature;
	}	

	private SignatureValue toSignatureValue(double vectorValue) {
		if (vectorValue > THRESHOLD) {
			return SignatureValue.HIGH_POSITIVE;
		} else if (vectorValue < -THRESHOLD){			
			return SignatureValue.HIGH_NEGATIVE;
		} else {
			return SignatureValue.LOW_VALUE;			
		}
	}
	
	public static float getRoughSimilarity(AbstractNode node1, AbstractNode node2) {
		if (node1 == null || node2 == null)
			return 0;
		
		// use the node signature to estimate the similarity
		WordSignature signature1 = node1.getSignature();
		WordSignature signature2 = node2.getSignature();
		WordSignature resultSignature = (WordSignature) signature1.clone();
		resultSignature.and(signature2);
		float similarity = (float)resultSignature.cardinality() / (float)resultSignature.getDimensionCount();
		
		return similarity;
	}
	
	public static float getAccurateSimilarity(AbstractNode node1, AbstractNode node2) {
		if (node1 == null || node2 == null)
			return 0;
		
		float[] mean1 = node1.getMean();
		float[] mean2 = node2.getMean();
		float similarity = VectorOperations.dotProduct(mean1, mean2);
		
		return similarity;
	}

	public static float getRoughDistance(AbstractNode node1, AbstractNode node2) {
		if (node1 == null || node2 == null)
			return 1;
		
		// use the node signature to estimate the similarity
		WordSignature signature1 = node1.getSignature();
		WordSignature signature2 = node2.getSignature();
		WordSignature resultSignature = (WordSignature) signature1.clone();
		resultSignature.xor(signature2);
		float distance = (float)resultSignature.cardinality() / (float)resultSignature.getDimensionCount();
		
		return distance;
	}
	
	public static float getAccurateDistance(AbstractNode node1, AbstractNode node2) {
		if (node1 == null || node2 == null)
			return 0;
		
		float[] mean1 = node1.getMean();
		float[] mean2 = node2.getMean();
		float distance = VectorOperations.getDistance(mean1, mean2, 2);
		
		return distance;
	}
}
