package com.sysomos.wordclustering.learning;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.sysomos.wordclustering.data.SignatureValue;
import com.sysomos.wordclustering.data.WordSignature;
import com.sysomos.wordclustering.node.ClusterClusterNode;
import com.sysomos.wordclustering.node.ClusterNode;
import com.sysomos.wordclustering.node.WordNode;

public class ClusterLearner extends AbstractLearner<ClusterNode<?>> {
	public static final int THRESHOLD_CHILDREN_COUNT = 20;
		
	private List<ClusterNode<?>> clusterNodeList;
	
	static class SignificantDimension {
		public int index;
		public double mean;
		public double weightedVariation;
		
		public SignificantDimension(int index, double mean, double weightedVariation) {
			this.index = index;
			this.mean = mean;
			this.weightedVariation = weightedVariation;
		}
	}
	
	public ClusterLearner(int level) {
		super(level);
		
		clusterNodeList = new ArrayList<ClusterNode<?>>();
	}

	@Override
	public void addNewNode(ClusterNode<?> newNode) {
		if (newNode != null)
			clusterNodeList.add(newNode);
	}

	@Override
	public void selfLearn() {
		System.out.println("Learning level = " + level);
		
		/*
		 * if the number of nodes is less than the threshold value, terminate the learning process
		 */
		if (clusterNodeList.size() <= THRESHOLD_CHILDREN_COUNT) {
			terminateLearning();
		} else {
			normalLearning();
			
			// create a parent learner to continue the learning
			parentLearner = new ClusterLearner(level + 1);
		}
	}
	
	private void normalLearning() {
		// create signature for each cluster, and use each signature to generate a parent cluster
		for (ClusterNode<?> clusterNode : clusterNodeList) {
			WordSignature signature = getGeneralizedSignature(clusterNode);
			
			ClusterNode<ClusterNode<?>> parentCluster = parentClusterMap.get(signature);
			if (parentCluster == null) {
				parentCluster = new ClusterClusterNode();
				parentClusterMap.put(signature, parentCluster);
			}
			
			// add the node to the parent cluster
			parentCluster.addChildNode(clusterNode);
		}
	}
		
	private void terminateLearning() {		
		// use a generic signature the only parent cluster, which is the root
		WordSignature signature = clusterNodeList.get(0).getGenericSignature();
		ClusterNode<ClusterNode<?>> rootCluster = new ClusterClusterNode();
		parentClusterMap.put(signature, rootCluster);
		
		for (ClusterNode<?> clusterNode : clusterNodeList) {
			rootCluster.addChildNode(clusterNode);
		}		
	}

	private WordSignature getGeneralizedSignature(ClusterNode<?> clusterNode) {
		/*
		 * Ignore low positive and low negative, set all of them to low negative "00"
		 * Among the high positives and high negatives, choose the top 70% with least weighted variations
		 * weighted variation = variation /|value|
		 * Set all other dimensions to "00"
		 */
		List<SignificantDimension> significantDimensionList = getSortedSignificantDimensionList(clusterNode);
		int chosenDimensionCount = scaleDownDimensionsToUse(significantDimensionList.size());
		
		// create a WordSignature with all 0s, and then sent the chosen dimensions to the non-zero values
		WordSignature signature = new WordSignature(clusterNode.getMean().length);
		for (int i = 0; i < chosenDimensionCount; i++) {
			SignificantDimension chosenDimension = significantDimensionList.get(i);
			if (chosenDimension.mean > 0) {
				signature.setDimension(chosenDimension.index, SignatureValue.HIGH_POSITIVE);
			} else {
				signature.setDimension(chosenDimension.index, SignatureValue.HIGH_NEGATIVE);				
			}
		}
		
		return signature;
	}
	
	private List<SignificantDimension> getSortedSignificantDimensionList(ClusterNode<?> clusterNode) {
		float[] mean = clusterNode.getMean();
		float[] variation = clusterNode.getVariation();
		List<SignificantDimension> significantDimensionList = new ArrayList<SignificantDimension>();
		for (int i = 0; i < mean.length; i++) {
			if ((mean[i] > WordNode.THRESHOLD) || (mean[i] < -WordNode.THRESHOLD)) {
				double weightedVariation = variation[i] / Math.abs(mean[i]);
				significantDimensionList.add(new SignificantDimension(i, mean[i], weightedVariation));
			}
		}
		
		// sort the list from low to high variation
		Comparator<SignificantDimension> comparator = new Comparator<SignificantDimension>() {

			@Override
			public int compare(SignificantDimension dimension1, SignificantDimension dimension2) {
				int variationResult = (int)Math.signum(dimension1.weightedVariation - dimension2.weightedVariation);
				if (variationResult != 0)
					return variationResult;
				else
					return (int)Math.signum(dimension2.mean - dimension1.mean);
			}			
		};
		
		Collections.sort(significantDimensionList, comparator);
		
		return significantDimensionList;
	}
	
	private int scaleDownDimensionsToUse(int originalCount) {
		float factor = 1;
		
		switch (level) {
		case 0:
			factor = 1;
		case 1:
			factor = 0.7f;
		case 2:
			factor = 0.5f;
		case 3:
			factor = 0.35f;
		case 4:
			factor = 0.3f;
		case 5:
			factor = 0.2f;
		case 6:
			factor = 0.15f;
		case 7:
			factor = 0.1f;
		case 8:
			factor = 0.07f;
		case 9:
			factor = 0.05f;
		default:
			factor = 0;
		}
		
		int reducedCount = Math.round(originalCount * factor);
		if (reducedCount <= 0 && originalCount > 0)
			reducedCount = 1;
		
		return reducedCount;
	}
}
