package com.sysomos.wordclustering.util;

public class IoUtil {

	public static String concatPaths(String mainPath, String secondPath) {
		if (mainPath == null)
			return secondPath;
		else if (secondPath == null)
			return mainPath;
		
		if (!mainPath.endsWith("/") && !secondPath.startsWith("/"))
			return mainPath + "/" + secondPath;
		else if (mainPath.endsWith("/") && secondPath.startsWith("/"))
			return mainPath + secondPath.substring(1);
		else
			return mainPath + secondPath;
	}
}
