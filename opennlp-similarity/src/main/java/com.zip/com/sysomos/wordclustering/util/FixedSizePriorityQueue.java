package com.sysomos.wordclustering.util;

import java.util.Comparator;
import java.util.PriorityQueue;

public class FixedSizePriorityQueue<T> extends PriorityQueue<T> {
	private static final long serialVersionUID = 1L;
	
	private int fixedSize;
	
	public FixedSizePriorityQueue(int fixedSize) {
		super(fixedSize + 5);
		
		this.fixedSize = fixedSize;
	}
	
	public FixedSizePriorityQueue(int fixedSize, Comparator<T> comparator) {

		super(fixedSize + 5, comparator);
		
		this.fixedSize = fixedSize;
	}

	public int getFixedSize() {
		return fixedSize;
	}
	
	@Override
	public boolean add(T item) {
		boolean status = super.add(item);
		
		// keep the size below or equal the fixed size
		if (size() > fixedSize) {
			T head = poll();
			if (item.equals(head)) {
				// the added item is the same as the removed, so no change to the queue
				return false;
			} else {
				return true;
			}
		}
		
		return status;
	}
}
