package com.sysomos.wordclustering.kmeans;

import java.util.List;

import com.sysomos.wordclustering.node.AbstractNode;
import com.sysomos.wordclustering.node.WordClusterNode;
import com.sysomos.wordclustering.node.WordNode;

public class KMeansLearnerBySimilarity extends KMeansLearner {
	
	public KMeansLearnerBySimilarity(List<WordNode> nodeList, KMeansLearner parentLearner) {
		super(nodeList, parentLearner);
	}

	@Override
	protected MostSimilarCluster getMostSimilarCluster(WordNode wordNode, List<WordClusterNode> clusterList) {
		if (wordNode == null || clusterList == null || clusterList.size() == 0)
			return null;
		
		boolean useEstimate = useEstimate();
		int clusterIndex = -1;
		float maxSimilarity = -1;
		for (int i = 0; i < clusterList.size(); i ++) {
			WordClusterNode wordClusterNode = clusterList.get(i);
			float similarity = 0;
			if (useEstimate)
				similarity = AbstractNode.getRoughSimilarity(wordNode, wordClusterNode);
			else
				similarity = AbstractNode.getAccurateSimilarity(wordNode, wordClusterNode);
				
			if (clusterIndex < 0 || similarity > maxSimilarity) {
				clusterIndex = i;
				maxSimilarity = similarity;
			}
		}
		
		// add the word node to the cluster that is most similar to the node
		MostSimilarCluster mostSimilarCluster = new MostSimilarCluster();
		mostSimilarCluster.similarity = maxSimilarity;
		mostSimilarCluster.cluster = clusterList.get(clusterIndex);
		
		return mostSimilarCluster;
	}
}
