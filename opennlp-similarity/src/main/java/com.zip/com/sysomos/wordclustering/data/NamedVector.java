package com.sysomos.wordclustering.data;

public class NamedVector {
	private String name;
	float[] vector;
	
	public NamedVector(String name, float[] vector) {
		this.name = name;
		this.vector = vector;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float[] getVector() {
		return vector;
	}

	public void setVector(float[] vector) {
		this.vector = vector;
	}
}
