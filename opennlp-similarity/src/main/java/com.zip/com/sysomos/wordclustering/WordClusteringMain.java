package com.sysomos.wordclustering;

import java.io.BufferedReader;
import java.io.FileReader;

import com.sysomos.wordclustering.data.NamedVector;
import com.sysomos.wordclustering.data.WordTable;
import com.sysomos.wordclustering.kmeans.HierarchicalLearner;
import com.sysomos.wordclustering.node.AbstractNode;
import com.sysomos.wordclustering.node.ClusterNode;
import com.sysomos.wordclustering.node.WordNode;

public class WordClusteringMain {
	HierarchicalLearner wordLearner;

	public WordClusteringMain() {
		wordLearner = new HierarchicalLearner();
	}

	private void loadData() throws Exception {
		WordTable wordTable = WordTable.getInstance();
		
		try (BufferedReader reader = new BufferedReader(new FileReader(GlobalConstants.INPUT_DIR))) {
			String line = null;
			NamedVector resultHolder = new NamedVector("place holder", new float[AbstractNode.VECTOR_LENGTH]);
			while ((line = reader.readLine()) != null) {
				boolean success = parseLine(line, resultHolder);
				if (success) {
					String word = resultHolder.getName();
					float[] vector = resultHolder.getVector();
					wordTable.addWordVector(word, vector);
					wordLearner.addWordNode(new WordNode(word));
				}
			}
		}
	}
	
	private boolean parseLine(String line, NamedVector resultHolder) {
		if (line.trim().length() == 0)
			return false;
		
		int colonPos = line.indexOf(":[");
		String word = line.substring(0, colonPos).trim();
		
		int closingBracket = line.indexOf("]", colonPos + 2);
		String vectorSting = line.substring(colonPos + 2, closingBracket);
		String[] valueStrings = vectorSting.split("\\,");
		
		float[] vector = new float[valueStrings.length];
		for (int i = 0; i < valueStrings.length; i++) {
			vector[i] = Float.parseFloat(valueStrings[i].trim());
		}
		
		resultHolder.setName(word);
		resultHolder.setVector(vector);
		
		return true;
	}
	
	private ClusterNode<?> learn() {
		return wordLearner.learn();
	}
	
	private void outputResults(ClusterNode<?> rootCluster) {
		try {
			rootCluster.outputResult(GlobalConstants.OUTPUT_DIR);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) throws Exception {
		WordClusteringMain instance = new WordClusteringMain();
		
		System.out.println("Loading data ...");
		instance.loadData();

		System.out.println("Learning ...");
		ClusterNode<?> rootCluster = instance.learn();

		System.out.println("Outputing result ...");
		instance.outputResults(rootCluster);
	}
}
