package com.sysomos.wordclustering.data;

/**
 * Storing word vectors as integers to minimize the memory use
 *
 */
public class VectorValue {
	private int[] intVector;
	
	public VectorValue(float[] vector) {
		setVector(vector);
	}
	
	public float[] getVector() {
		if (intVector == null)
			return null;
		
		float[] floatVector = new float[intVector.length];
		for (int i = 0; i < intVector.length; i++) {
			floatVector[i] = 0.001f * (float)intVector[i];
		}
		
		return floatVector;
	}
	
	public void setVector(float[] vector) {
		if (vector == null) {
			intVector = null;
			return;
		}
		
		intVector = new int[vector.length];
		for (int i = 0; i < intVector.length; i++) {
			intVector[i] = (int)(vector[i] * 1000f);
		}
	}
	
	public void clear() {
		intVector = null;
	}
}
