package com.sysomos.wordclustering.data;

public enum SignatureValue {
	
	HIGH_POSITIVE(true, false),
	HIGH_NEGATIVE(false, true),
	LOW_VALUE(false, false);

    private boolean highBit;
    private boolean lowBit;

    SignatureValue(boolean highBit, boolean lowBit) {
        this.highBit = highBit;
        this.lowBit = lowBit;
    }
    
    public boolean getHighBit() {
		return highBit;
	}

	public boolean getLowBit() {
		return lowBit;
	}
}