package com.sysomos.wordclustering.learning;

import com.sysomos.wordclustering.data.WordSignature;
import com.sysomos.wordclustering.node.ClusterNode;
import com.sysomos.wordclustering.node.WordClusterNode;
import com.sysomos.wordclustering.node.WordNode;

public class WordLearner extends AbstractLearner<WordNode> {
	
	public WordLearner() {
		super(0);
	}

	@Override
	public void addNewNode(WordNode wordNode) {
		// do self learning hear to save memory
		WordSignature signature = wordNode.getSignature();
		ClusterNode<WordNode> parentCluster = parentClusterMap.get(signature);
		if (parentCluster == null) {
			parentCluster = new WordClusterNode();
			parentClusterMap.put(signature, parentCluster);
		}
		
		parentCluster.addChildNode(wordNode);
	}

	@Override
	public void selfLearn() {
		// it has been done in addNewNode() to save memory, so do nothing
		outputResults();
		
		// create parent learner to continue the learning
		parentLearner = new ClusterLearner(level + 1);
	}
	
	private void outputResults() {
		System.out.println("Clusters");
		for (ClusterNode<WordNode> cluster : parentClusterMap.values()) {
			if (cluster.getChildrenList().size() > 1) {
				System.out.println("Cluster: " + cluster.getCentroidWord());
				for (WordNode wordNode : cluster.getChildrenList()) {
					System.out.println("\t" + wordNode.getWord());
				}
			}
		}
		
	}
}
