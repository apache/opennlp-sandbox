package com.sysomos.wordclustering.data;

import java.util.HashMap;
import java.util.Map;

import com.sysomos.wordclustering.GlobalConstants;

public class WordTable {
	private static volatile WordTable instance;
	Map<String, VectorValue> wordMap;			// store vectors as integers to minimize the memory use
	
	public static WordTable getInstance() {
		if (instance == null)
			instance = new WordTable();
		
		return instance;
	}
	
	private WordTable() {
		wordMap = new HashMap<String, VectorValue>(GlobalConstants.WORD_COUNT, 1);
	}
	
	public float[] getVector(String word) {
		if (word == null)
			return null;
		
		VectorValue vectorValue = wordMap.get(word);
		if (vectorValue == null)
			return null;
		else		
			return vectorValue.getVector();
	}
	
	public void addWordVector(String word, float[] vector) {
		if (word == null) {
			System.err.println("Word cannot be null.");
			return;
		}
				
		wordMap.put(word, new VectorValue(vector));
	}
}
