package com.sysomos.wordclustering.api;

import java.util.Comparator;

import com.sysomos.wordclustering.util.FixedSizePriorityQueue;

public class SimilarWordQueue extends FixedSizePriorityQueue<SimilarWord> {
	private static final long serialVersionUID = 1L;

	public SimilarWordQueue(int fixedSize) {
		super(fixedSize, createComparator());
	}
	
	public SimilarWord[] getWordList() {
		int queueSize = size();
		SimilarWord[] words = new SimilarWord[queueSize];
		
		// the head is the least value, so reverse the order
		for (int i = queueSize - 1; i >= 0; i--) {
			words[i] = poll();
		}
		
		return words;
	}

	private static Comparator<SimilarWord> createComparator() {
		return new Comparator<SimilarWord>() {

			@Override
			public int compare(SimilarWord word1, SimilarWord word2) {
				return (int)Math.signum(word1.similarity - word2.similarity);
			}
		};
	}
	
	public static void main(String[] args) {
		SimilarWordQueue queue = new SimilarWordQueue(3);
		SimilarWord[] similarWords = {
				new SimilarWord("word1", 0.7f),
				new SimilarWord("word2", 0.5f),
				new SimilarWord("word3", 0.9f),
				new SimilarWord("word4", 0.8f)
		};
		
		for (SimilarWord word : similarWords) {
			queue.add(word);
		}
				
		for (SimilarWord word : queue.getWordList()) {
			System.out.println(word.word + " = " + word.similarity);
		}
	}
}
