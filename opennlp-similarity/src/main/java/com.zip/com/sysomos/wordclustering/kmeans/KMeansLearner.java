package com.sysomos.wordclustering.kmeans;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import com.sysomos.wordclustering.node.AbstractNode;
import com.sysomos.wordclustering.node.ClusterNode;
import com.sysomos.wordclustering.node.WordClusterNode;
import com.sysomos.wordclustering.node.WordNode;
import com.sysomos.wordclustering.util.VectorOperations;

@SuppressWarnings({"rawtypes","unchecked"})
public abstract class KMeansLearner {
	public static final int MIN_NODES_IN_CLUSTER = 30;
	public static final int MAX_CLUSTERS = 20;
	public static final int MIN_CLUSTERS = 3;	
	public static final int SAMPLING_SIZE = 100;
	public static final int MAX_ROUNDS = 8;
	public static final int MIN_ROUNDS = 8;
	public static final float MEAN_DIFF_THRESHOLD = 0.02f;
	
	
	// when number of nodes is above the threshold, use rough estimate to improve performance
	private static final int SIZE_THRESHOLD_ACCURACY = 200000;
	
	static class MostSimilarCluster {
		public float similarity;
		public WordClusterNode cluster;
	}
	
	protected KMeansLearner parentLearner;
	protected List<WordNode> wordNodeList;
	protected ClusterNode resultCluster;	// hold the hierarchical result
	protected List<WordClusterNode> wordClusterList;
	protected int clusterCount;
	protected int level = 0;
		
	public KMeansLearner(List<WordNode> nodeList, KMeansLearner parentLearner) {
		this.wordNodeList = nodeList;
		this.parentLearner = parentLearner;
		if (parentLearner != null)
			level = parentLearner.level + 1;
		else
			level = 0;
	}
	
	protected abstract MostSimilarCluster getMostSimilarCluster(WordNode wordNode, List<WordClusterNode> clusterList);
		
	public List<WordNode> getWordNodeList() {
		return wordNodeList;
	}

	public List<WordClusterNode> learn() {
		clusterCount = determineClusterCount();
		if (clusterCount <= 1) {
			// no further splitting is necessary
			WordClusterNode cluster = new WordClusterNode();
			cluster.getChildrenList().addAll(wordNodeList);
			wordClusterList = new ArrayList<WordClusterNode>();
			wordClusterList.add(cluster);
			
			return wordClusterList;
		}
		
		choseInitialClusterMeans(clusterCount);
		
		int round = 0;
		while (true) {
			// assign all the nodes to the closest cluster
			for (WordNode wordNode : wordNodeList) {
				assignNodeToCluster(wordNode, wordClusterList);
			}
			
			System.out.println("Level: " + level + ", Round: " + round + ", word count = " + wordNodeList.size());
			
			// finish if reached max number of rounds
			round++;
			if (round >= MAX_ROUNDS) {
				break;
			}
			
			// finish if the max mean difference is less than the threshold value
			float meanDiff = setNewMeansToClusters();
			if (meanDiff < MEAN_DIFF_THRESHOLD && round >= MIN_ROUNDS) {
				break;
			}
			
			// clear the clusters
			for (WordClusterNode cluster : wordClusterList) {
				cluster.getChildrenList().clear();
			}
		}
		
		// remove the empty clusters
		Iterator<WordClusterNode> iterator = wordClusterList.iterator();
		while(iterator.hasNext()) {
			WordClusterNode cluster = iterator.next();
			if (cluster.getChildrenList().isEmpty())
				iterator.remove();
		}
		
		return wordClusterList;
	}
	
	public ClusterNode<?> getResultCluster() {
		return resultCluster;
	}
	
	public void setResultCluster(ClusterNode<? extends AbstractNode> resultCluster) {
		this.resultCluster = resultCluster;
		if (resultCluster != null && parentLearner != null) {
			parentLearner.addChildCluster(resultCluster);
		}
	}
	
	public void addChildCluster(ClusterNode childCluster) {
		resultCluster.addChildNode(childCluster);
	}
	
	
	protected boolean useEstimate() {
		if (wordNodeList.size() > SIZE_THRESHOLD_ACCURACY)
			return true;
		else
			return false;
	}
	
	private int determineClusterCount() {
		if (wordNodeList == null || wordNodeList.size() == 0) {
			return 0;
		} else if (wordNodeList.size() <= MIN_NODES_IN_CLUSTER) {
			return 1;
		}
		
		// try to put MIN_NODES_IN_CLUSTER nodes in each cluster
		int recommendedClusterCount = wordNodeList.size() / MIN_NODES_IN_CLUSTER;
		if (recommendedClusterCount >= MAX_CLUSTERS) {
			recommendedClusterCount = MAX_CLUSTERS;
		} else if ((wordNodeList.size() % MIN_NODES_IN_CLUSTER) != 0) {
			recommendedClusterCount++;
		}
		
		if (recommendedClusterCount < MIN_CLUSTERS)
			recommendedClusterCount = MIN_CLUSTERS;
		
		return recommendedClusterCount;		
	}
	
	private void choseInitialClusterMeans(int clusterCount) {
		wordClusterList = new ArrayList<WordClusterNode>(clusterCount);
		for (int i = 0; i < clusterCount; i++) {
			List<WordNode> candidateList = getClusterMeanCandidates();
			WordNode meanNode = findLeastSimilarNodeToClusters(candidateList, wordClusterList);
			
			// use the least similar node as a the mean of a new cluster
			WordClusterNode cluster = new WordClusterNode();
			cluster.setMean(meanNode.getMean());
			wordClusterList.add(cluster);
		}		
	}
	
	private List<WordNode> getClusterMeanCandidates() {
		
		List<WordNode> candidateList = new ArrayList<WordNode>();

		// if the number of nodes is significantly more than sampling size, random pick the candidates
		// else use all nodes as candidates
		int poolSize = wordNodeList.size() - wordClusterList.size();
		if (poolSize >= 2 * SAMPLING_SIZE) {
			// do random sampling
			Random random = new Random();
			for (int i = 0; i < SAMPLING_SIZE; i++) {
				candidateList.add(wordNodeList.get(random.nextInt(wordNodeList.size())));
			}
		} else {
			// use all nodes as candidates
			candidateList.addAll(wordNodeList);
		}
		
		return candidateList;
	}

	private WordNode findLeastSimilarNodeToClusters(
			List<WordNode> nodeCandidateList, List<WordClusterNode> clusterList) 
	{
		if (nodeCandidateList == null || nodeCandidateList.size() == 0 || clusterList == null)
			return null;
		
		// pick the first word if the cluster list is empty
		if (clusterList.size() == 0)
			return nodeCandidateList.get(0);
		
		int candidateIndex = -1;
		float leastSimilarity = -1;
		for (int i = 0; i < nodeCandidateList.size(); i++) {
			WordNode canidateNode = nodeCandidateList.get(i);
			MostSimilarCluster mostSimilarCluster = getMostSimilarCluster(canidateNode, clusterList);
			if (candidateIndex < 0 || mostSimilarCluster.similarity < leastSimilarity) {
				leastSimilarity = mostSimilarCluster.similarity;
				candidateIndex = i;
			}
		}
		
		// select the word node that is least similar to the clusters
		return nodeCandidateList.get(candidateIndex);
	}
	
	private void assignNodeToCluster(WordNode wordNode, List<WordClusterNode> clusterList) {
		MostSimilarCluster mostSimilarCluster = getMostSimilarCluster(wordNode, clusterList);
		
		// add the word node to the cluster that is most similar to the node
		if (mostSimilarCluster != null) {
			mostSimilarCluster.cluster.addChildNode(wordNode);
		}
	}

	private float setNewMeansToClusters() {
		float maxMeanDiff = -1;
		Iterator<WordClusterNode> clusterIterator = wordClusterList.iterator();
		while (clusterIterator.hasNext()) {
			WordClusterNode wordCluster = clusterIterator.next();
			
			// remove the empty clusters
			if (wordCluster.getChildrenList().isEmpty()) {
				clusterIterator.remove();
				continue;
			}
			
			float[] oldMean = wordCluster.getMean();
			wordCluster.refreshMeanAndVariation();
			float[] newMean = wordCluster.getMean();
			float meanDiff = VectorOperations.getDistance(oldMean, newMean, 2);
			if (meanDiff > maxMeanDiff) {
				maxMeanDiff = meanDiff;
			}
		}
		
		return maxMeanDiff;
	}
}
