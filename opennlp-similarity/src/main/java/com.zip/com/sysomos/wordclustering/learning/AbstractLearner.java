package com.sysomos.wordclustering.learning;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.sysomos.wordclustering.data.WordSignature;
import com.sysomos.wordclustering.node.AbstractNode;
import com.sysomos.wordclustering.node.ClusterNode;

public abstract class AbstractLearner<T extends AbstractNode> {
	protected int level = 0;			// Level word learner is 0, it increment by 1 for each the parent learner.
	protected ClusterLearner parentLearner;
	protected Map<WordSignature, ClusterNode<T>> parentClusterMap;
	
	public AbstractLearner(int level) {
		this.level = level;
		parentClusterMap = new HashMap<WordSignature, ClusterNode<T>>();
	}
	
	public abstract void addNewNode(T newNode);
	public abstract void selfLearn();
	
	public void learn() {
		
		// associate all nodes this learner owns to a parent cluster, 
		// also decides whether need to create a parent learner
		selfLearn();
		
		// merge the single node clusters to other clusters
		mergeSingleNodeClustersToOtherClusters();
		
		if (parentLearner != null) {
			// add all parent clusters to parent learner and learn recursively
			for (ClusterNode<?> parentNode : parentClusterMap.values()) {
				parentLearner.addNewNode(parentNode);
			}		
			parentLearner.learn();
		}
	}
	
	public ClusterNode<?> getRootCluster() {
		// Root cluster is the parent cluster contained in the root learner
		// Root learner is the learner that does not have parent learner
		if (parentLearner == null) {
			return parentClusterMap.values().iterator().next();
		} else {
			return parentLearner.getRootCluster();
		}
	}
	
	private void mergeSingleNodeClustersToOtherClusters() {
		// get all the signatures of the clusters that have multiple nodes
		// we will merge all the clusters of single node to these clusters
		Set<WordSignature> signaturesMergeTo = getSignatureSetOfClustersWithMultipleChidren();
		for (WordSignature signature : parentClusterMap.keySet()) {
			if (signaturesMergeTo.contains(signature)) {
				// this is a cluster that contains multiple nodes, do nothing
				continue;
			} else {
				// find the cluster that is closest to this cluster
				WordSignature signatureMergeTo = findClosestCluster(signature, signaturesMergeTo);
				
				// merge the child node of the single-node cluster to the closest multiple-node cluster
				ClusterNode<T> clusterToMerge = parentClusterMap.remove(signature);
				T childNode = clusterToMerge.getChildrenList().get(0);
				try {
				parentClusterMap.get(signatureMergeTo).addChildNode(childNode);
				} catch (Exception e) {
					e.printStackTrace();
				}
				clusterToMerge.destroy();
				clusterToMerge = null; 
			}
		}
	}
	
	private Set<WordSignature> getSignatureSetOfClustersWithMultipleChidren() {
		Set<WordSignature> signatureSet = new HashSet<WordSignature>();
		for (WordSignature signature : parentClusterMap.keySet()) {
			ClusterNode<T> cluster = parentClusterMap.get(signature);
			if (cluster.getChildrenList().size() > 1) {
				signatureSet.add(signature);
			}
		}
		
		return signatureSet;
	}
	
	private WordSignature findClosestCluster(WordSignature signatureToMerge, Set<WordSignature> signaturesMergeTo) {
		// use the reusable signature to minimize the memory use
		WordSignature reusableSignature = new WordSignature(signatureToMerge.getDimensionCount());
		
		int maxSimilarity = -1;
		WordSignature signatureMergeTo = null;
		for (WordSignature signature : signaturesMergeTo) {
			// do a copy to the reusable signature, the value of the signature will change after the AND operation
			WordSignature.copy(reusableSignature, signatureToMerge);
			
			// we use the bit AND to calculate the similarity between two signatures
			reusableSignature.and(signature);
			int similarity = reusableSignature.cardinality();
			if (similarity > maxSimilarity) {
				maxSimilarity = similarity;
				signatureMergeTo = signature;
			}
		}
		
		return signatureMergeTo;
	}
}
