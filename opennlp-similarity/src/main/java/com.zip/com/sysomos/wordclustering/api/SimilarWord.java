package com.sysomos.wordclustering.api;

public class SimilarWord {
	public String word;
	public float similarity;
	public SimilarWord(String word, float similarity) {
		this.word = word;
		this.similarity = similarity;
	}
}
