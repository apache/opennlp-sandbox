package com.sysomos.wordclustering.node;

import java.io.File;
import java.io.IOException;

import com.sysomos.wordclustering.util.IoUtil;

public class ClusterClusterNode extends ClusterNode<ClusterNode<?>> {
	@Override
	public void outputResult(String dirPath) throws IOException {
		File dir = new File(dirPath);
		if (!dir.exists()) {
			dir.mkdirs();
		}
				
		for (ClusterNode<?> child : childrenList) {
			String centroidWord = child.getCentroidWord();
			String childDirPath = IoUtil.concatPaths(dirPath, centroidWord);
			child.outputResult(childDirPath);
		}
	}
}
